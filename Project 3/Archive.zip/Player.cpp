//
//  Player.cpp
//  Project 3
//
//  Created by Brian Chang on 5/19/20.
//  Copyright © 2020 Brian Chang. All rights reserved.
//

#include "Player.h"
#include "Actor.h"

void Player::makemove()
{
    
}
