//
//  main.cpp
//  Project 3
//
//  Created by Brian Chang on 5/19/20.
//  Copyright © 2020 Brian Chang. All rights reserved.
//

#include <iostream>
#include "globals.h"
#include "Dungeon.h"

using namespace std;


int main()
{
    Dungeon D;
    D.printDungeon();
}
